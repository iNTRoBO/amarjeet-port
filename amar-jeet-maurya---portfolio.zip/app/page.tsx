'use client'

import React from 'react'
import Navbar from '@/components/Navbar'
import Hero from '@/components/Hero'
import AboutEducation from '@/components/AboutEducation'
import Skills from '@/components/Skills'
import Experience from '@/components/Experience'
import Projects from '@/components/Projects'
import Certifications from '@/components/Certifications'
import ContactCTA from '@/components/ContactCTA'
import Footer from '@/components/Footer'
import { Plus_Jakarta_Sans, Caveat, Great_Vibes } from 'next/font/google'

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-jakarta',
})

const caveat = Caveat({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-caveat',
})

const calligraphy = Great_Vibes({
  subsets: ['latin'],
  weight: ['400'],
  variable: '--font-calligraphy',
})

export default function Page() {
  return (
    <main className={`${jakarta.className} ${caveat.variable} ${calligraphy.variable} bg-white selection:bg-[#FF4B22] selection:text-white antialiased`}>
      <Navbar />
      <Hero />
      <AboutEducation />
      <Skills />
      <Experience />
      <Projects />
      <Certifications />
      <ContactCTA />
      <Footer />
    </main>
  )
}
