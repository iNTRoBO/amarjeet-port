import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Amar Jeet Maurya | Web Developer & AI Technologist',
  description: 'Personal portfolio website for Amar Jeet Maurya, featuring web development projects, experience, and academic background.',
  openGraph: {
    title: 'Amar Jeet Maurya | Web Developer & AI Technologist',
    description: 'Personal portfolio website for Amar Jeet Maurya, featuring web development projects, experience, and academic background.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Amar Jeet Maurya | Web Developer & AI Technologist',
    description: 'Personal portfolio website for Amar Jeet Maurya, featuring web development projects, experience, and academic background.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
