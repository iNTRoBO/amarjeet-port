'use client'

import React from 'react'
import { Linkedin, Github, Twitter, Instagram } from 'lucide-react'
import GradientWaves from './GradientWaves'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Education', href: '#education' },
    { name: 'Projects', href: '#projects' },
    { name: 'Experience', href: '#experience' },
    { name: 'Contact', href: '#contact' },
  ]

  return (
    <footer className="bg-[#111111] pt-24 pb-12 px-6 relative overflow-hidden min-h-[400px]">
      <div className="absolute inset-0 opacity-40 pointer-events-none">
        <GradientWaves
          horizonColor="#111111"
          waveColor="#222222"
          crestColor="#FF4B22"
          speed={0.3}
          amplitude={1.5}
          waveScale={0.5}
          waveRatio={0.8}
          swell={25}
          turbulence={15}
          tilt={1.2}
          zoom={0.8}
          height={6.0}
          fogDepth={20}
          detail="medium"
          brightness={0.8}
          opacity={1.0}
          mouseInteraction={true}
          parallaxStrength={0.3}
          grain={true}
          grainIntensity={0.03}
        />
      </div>

      <div className="max-w-7xl mx-auto space-y-20 relative z-10">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-12">
          <div className="space-y-2">
            <h2 className="text-4xl font-black text-white leading-none">
              Amar Jeet<br />
              <span className="text-[#FF4B22] font-calligraphy normal-case text-6xl inline-block -rotate-3 -mt-2">Maurya</span>
            </h2>
            <p className="text-white/30 text-[10px] font-black uppercase tracking-[0.4em] pt-4">WEB & AI TECHNOLOGIST</p>
          </div>

          <div className="flex flex-wrap gap-x-12 gap-y-6">
            {navItems.map((item) => (
              <a 
                key={item.name} 
                href={item.href}
                className="text-white/40 hover:text-[#FF4B22] text-sm font-bold uppercase tracking-widest transition-colors"
              >
                {item.name}
              </a>
            ))}
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
          <p className="text-white/20 text-xs font-medium tracking-wide">
            © {currentYear} Amar Jeet Maurya. All rights reserved.
          </p>

          <div className="flex gap-6">
            {[
              { Icon: Linkedin, href: '#' },
              { Icon: Github, href: '#' },
              { Icon: Twitter, href: '#' },
              { Icon: Instagram, href: 'https://www.instagram.com/amarjeet___2120?stkn=MWsxbXh5ZDZmdDc5Mw==' }
            ].map((social, idx) => (
              <a 
                key={idx} 
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white/20 hover:text-[#FF4B22] transition-colors"
              >
                <social.Icon size={20} />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
