'use client'

import React from 'react'
import { motion } from 'motion/react'
import { ArrowRight } from 'lucide-react'
import FoldButton from './FoldButton'

export default function ContactCTA() {
  return (
    <section id="contact" className="py-24 px-6 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="bg-[#111111] p-20 rounded-[4rem] text-center space-y-10 relative overflow-hidden"
      >
        {/* Subtle decorative squiggle */}
        <div className="absolute top-0 right-0 w-64 h-64 opacity-10 pointer-events-none select-none -mr-20 -mt-20">
          <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
            <path fill="#FF4B22" d="M44.7,-76.4C58.1,-69.2,69.2,-58.1,76.4,-44.7C83.7,-31.3,87.1,-15.7,85.6,-0.9C84,13.9,77.5,27.8,68.9,40.1C60.3,52.4,49.6,63.1,36.7,70.1C23.8,77.1,8.7,80.4,-6.2,79.5C-21.1,78.5,-35.8,73.4,-48.5,64.4C-61.2,55.4,-71.8,42.5,-77.8,27.8C-83.8,13.1,-85.1,-3.4,-81.4,-18.6C-77.7,-33.8,-69,-47.7,-57,-55.8C-45,-63.9,-29.7,-66.2,-15.7,-71.4C-1.7,-76.6,11,-84.7,26.7,-84.2C42.3,-83.7,31.3,-83.6,44.7,-76.4Z" transform="translate(100 100)" />
          </svg>
        </div>

        <div className="relative z-10 max-w-3xl mx-auto space-y-8">
          <h3 className="text-6xl lg:text-8xl font-black text-white leading-[0.9]">
            Have a <span className="text-[#FF4B22] font-calligraphy normal-case lg:text-[10rem] inline-block -rotate-3 ml-2">Project</span><br />in Mind?
          </h3>
          
          <p className="text-white/60 text-xl font-medium leading-relaxed">
            Feel free to reach out. I’m always open to new opportunities and exciting collaborations.
          </p>

          <div className="pt-8">
            <FoldButton 
              label="Get In Touch" 
              className="scale-125 hover:scale-150 transition-transform duration-500" 
              onClick={() => window.open('https://wa.me/917905892369', '_blank')}
            />
          </div>
        </div>

        {/* Handwritten signature/squiggle mockup */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 opacity-20 pointer-events-none">
          <svg width="200" height="60" viewBox="0 0 200 60" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 40C30 35 50 45 70 40C90 35 110 25 130 30C150 35 170 50 190 45" stroke="#FF4B22" strokeWidth="4" strokeLinecap="round" />
          </svg>
        </div>
      </motion.div>
    </section>
  )
}
