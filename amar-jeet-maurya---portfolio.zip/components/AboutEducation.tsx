'use client'

import React from 'react'
import { motion } from 'motion/react'
import { GraduationCap, FileText, Code2, Cpu } from 'lucide-react'

export default function AboutEducation() {
  return (
    <section id="about" className="py-24 px-6 max-w-7xl mx-auto space-y-12">
      <div className="grid lg:grid-cols-2 gap-8">
        {/* About Card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-[#F3F3F3] p-12 rounded-[3rem] relative overflow-hidden group"
        >
          <div className="relative z-10 space-y-8">
            <div className="inline-block px-6 py-2 rounded-full border border-[#111111]/10 text-xs font-black uppercase tracking-[0.2em] text-[#FF4B22] bg-[#111111]/5">
              About Me
            </div>
            
            <h3 className="text-5xl font-black text-[#111111] leading-tight">
              My <span className="text-[#FF4B22] font-calligraphy normal-case text-7xl inline-block -rotate-3 ml-2">Profile</span>
            </h3>

            <p className="text-[#111111]/70 leading-relaxed font-medium">
              I’m a curious and creative Web Developer who enjoys turning ideas into clean, responsive, and engaging digital experiences. I’ve gained hands-on experience through internships and projects in website development, poster design, and digital advertising. I work with front-end technologies, AI Prompt Engineering, and modern design tools, and I’m always exploring new ways to improve my skills. I enjoy solving problems, working with people, and bringing creative ideas to life.
            </p>

            <div className="pt-8 flex gap-6">
              <div className="p-4 bg-white rounded-2xl shadow-sm group-hover:scale-110 transition-transform">
                <Code2 size={32} className="text-[#FF4B22]" />
              </div>
              <div className="p-4 bg-white rounded-2xl shadow-sm group-hover:scale-110 transition-transform delay-75">
                <Cpu size={32} className="text-[#FF4B22]" />
              </div>
            </div>
          </div>

          {/* Decorative Illustration Background */}
          <div className="absolute bottom-0 right-0 opacity-5 -mb-12 -mr-12 scale-150 rotate-12">
            <Code2 size={300} strokeWidth={1} />
          </div>
        </motion.div>

        {/* Education Card */}
        <motion.div
          id="education"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="bg-[#111111] p-12 rounded-[3rem] relative overflow-hidden"
        >
          <div className="relative z-10 space-y-12">
            <div className="space-y-4">
              <div className="inline-block px-6 py-2 rounded-full border border-white/10 text-xs font-black uppercase tracking-[0.2em] text-[#FF4B22] bg-white/5">
                Education
              </div>
              
              <h3 className="text-5xl font-black text-white leading-tight">
                Academic <span className="text-[#FF4B22] font-calligraphy normal-case text-7xl inline-block -rotate-3 ml-2">Background</span>
              </h3>
            </div>

            <div className="space-y-8">
              {/* Education Item 1 */}
              <div className="flex gap-6 items-start relative group">
                <div className="w-12 h-12 rounded-2xl bg-[#FF4B22] flex items-center justify-center shrink-0 shadow-[0_0_20px_rgba(255,75,34,0.3)]">
                  <GraduationCap size={24} className="text-white" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-xl font-bold text-white group-hover:text-[#FF4B22] transition-colors">Bachelor of Computer Applications (BCA)</h4>
                  <p className="text-[#FF4B22] font-bold text-sm">GLA University, Mathura</p>
                  <p className="text-white/40 text-[12px] font-medium tracking-widest uppercase">2024 – 2027 (Expected)</p>
                  <p className="text-white/60 text-sm leading-relaxed max-w-sm pt-2">
                    Relevant coursework: Programming, Data Structures, Computer Networks, Database Management.
                  </p>
                </div>
              </div>

              {/* Education Item 2 */}
              <div className="flex gap-6 items-start relative group">
                <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center shrink-0">
                  <FileText size={24} className="text-[#FF4B22]" />
                </div>
                <div className="space-y-2">
                  <h4 className="text-xl font-bold text-white group-hover:text-[#FF4B22] transition-colors">Higher Secondary (Class 12th)</h4>
                  <p className="text-[#FF4B22] font-bold text-sm">CBSE</p>
                  <p className="text-white/40 text-[12px] font-medium tracking-widest uppercase">2024 – 2025</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
