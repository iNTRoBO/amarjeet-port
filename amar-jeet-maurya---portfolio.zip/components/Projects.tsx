'use client'

import React from 'react'
import { motion } from 'motion/react'
import { ArrowUpRight } from 'lucide-react'
import Image from 'next/image'
import proj1 from '../src/assets/images/regenerated_image_1791187479037.png'
import proj2 from '../src/assets/images/regenerated_image_1791187488298.png'
import proj3 from '../src/assets/images/regenerated_image_1791187493014.png'
import proj4 from '../src/assets/images/regenerated_image_1791187498026.png'
import proj5 from '../src/assets/images/regenerated_image_1791187500374.png'

const projects = [
  {
    id: "01",
    title: "Interactive Personality Quiz Web Application",
    description: "Developed an interactive web-based personality quiz using HTML, CSS, and JavaScript. Implemented dynamic question handling and real-time result generation.",
    tags: ["HTML", "CSS", "JavaScript"],
    image: proj1,
    color: "bg-[#111111]"
  },
  {
    id: "02",
    title: "Sales Trend Visualization System",
    description: "Created a web application to visualize sales trends using charts and graphical data representation. Improved data understanding through interactive dashboards.",
    tags: ["HTML", "CSS", "JavaScript"],
    image: proj2,
    color: "bg-[#F3F3F3]"
  },
  {
    id: "03",
    title: "Jarvis Voice Recognition Assistant",
    description: "Built a browser-based voice assistant capable of recognizing voice commands. Implemented speech recognition for basic automation and user interaction.",
    tags: ["JavaScript", "Web APIs"],
    image: proj3,
    color: "bg-[#111111]"
  },
  {
    id: "04",
    title: "Iron Man 3D Website",
    description: "Designed a modern, animated 3D-inspired website with responsive layouts and interactive UI elements.",
    tags: ["HTML", "CSS", "JavaScript"],
    image: proj4,
    color: "bg-[#F3F3F3]"
  },
  {
    id: "05",
    title: "Website Data – Balaji Tech Solutions",
    description: "Contributed to the development and enhancement of business websites during internship. Focused on responsive design, UI improvements, and user-friendly navigation.",
    tags: ["HTML", "CSS", "JavaScript"],
    image: proj5,
    color: "bg-[#111111]"
  }
]

export default function Projects() {
  return (
    <section id="projects" className="py-24 px-6 max-w-7xl mx-auto space-y-20">
      <div className="flex flex-col md:flex-row justify-between items-end gap-8">
        <div className="space-y-4">
          <div className="inline-block px-6 py-2 rounded-full border border-[#111111]/10 text-xs font-black uppercase tracking-[0.2em] text-[#FF4B22] bg-[#111111]/5">
            Key Projects
          </div>
          <h3 className="text-6xl font-black text-[#111111] leading-tight">
            My Featured <span className="text-[#FF4B22] font-calligraphy normal-case text-8xl inline-block -rotate-3 ml-2">Projects</span>
          </h3>
        </div>
        <div className="max-w-xs">
          <p className="text-[#111111]/40 text-sm font-medium leading-relaxed">
            A selection of my recent work in web development and interactive UI design.
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {projects.map((project, index) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className={`group rounded-[3rem] overflow-hidden ${project.color === 'bg-[#111111]' ? 'text-white' : 'text-[#111111]'} ${project.color} border border-[#111111]/5 flex flex-col`}
          >
            <div className="p-10 space-y-8 flex-1">
              <div className="flex justify-between items-start">
                <span className={`text-[12px] font-black tracking-widest ${project.color === 'bg-[#111111]' ? 'text-white/20' : 'text-[#111111]/10'}`}>
                  PROJECT {project.id}
                </span>
                <div className={`w-12 h-12 rounded-full border ${project.color === 'bg-[#111111]' ? 'border-white/10' : 'border-[#111111]/10'} flex items-center justify-center group-hover:bg-[#FF4B22] group-hover:border-[#FF4B22] transition-all duration-500`}>
                  <ArrowUpRight size={20} className={project.color === 'bg-[#111111]' ? 'text-white' : 'text-[#111111] group-hover:text-white'} />
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-3xl font-black leading-tight group-hover:text-[#FF4B22] transition-colors">
                  {project.title}
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${project.color === 'bg-[#111111]' ? 'text-white/60' : 'text-[#111111]/60'}`}>
                  {project.description}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                {project.tags.map(tag => (
                  <span key={tag} className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest border ${project.color === 'bg-[#111111]' ? 'border-white/10 bg-white/5' : 'border-[#111111]/10 bg-[#111111]/5'}`}>
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="relative aspect-[16/9] overflow-hidden m-6 rounded-[2rem]">
              <Image 
                src={project.image} 
                alt={project.title}
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-all duration-500"></div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
