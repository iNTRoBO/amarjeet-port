'use client';

import React from 'react';
import './FoldButton.css';

interface FoldButtonProps {
  label?: string;
  onClick?: () => void;
  className?: string;
}

export default function FoldButton({ label = 'Credits', onClick, className = '' }: FoldButtonProps) {
  return (
    <button type="button" className={`fold-button ${className}`} onClick={onClick}>
      <span className="fold-button__fold"></span>

      <div className="fold-button__points-wrapper">
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
        <i className="fold-button__point"></i>
      </div>

      <span className="fold-button__inner">
        <svg
          className="icon"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.5"
        >
          <polyline points="13.18 1.37 13.18 9.64 21.45 9.64 10.82 22.63 10.82 14.36 2.55 14.36 13.18 1.37"></polyline>
        </svg>
        {label}
      </span>
    </button>
  );
}
