'use client'

import React from 'react'
import { motion } from 'motion/react'
import { Download, ArrowRight, MapPin, Mail, Phone } from 'lucide-react'
import Image from 'next/image'
import profilePic from '../src/assets/images/regenerated_image_1791192738595.png'

export default function Hero() {
  return (
    <section id="home" className="pt-40 pb-20 px-6 max-w-7xl mx-auto min-h-screen flex flex-col lg:flex-row items-center gap-12">
      {/* Left Column */}
      <div className="flex-1 space-y-8 lg:-mt-16">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="inline-block px-6 py-2 rounded-full border border-[#111111]/10 text-sm font-black uppercase tracking-[0.2em] text-[#111111]/80 bg-[#111111]/5"
        >
          Hello!
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-7xl lg:text-9xl font-black leading-[0.6] tracking-tighter text-[#111111]"
        >
          Amar Jeet<br />
          <span className="text-[#FF4B22] font-calligraphy font-bold tracking-normal normal-case block lg:inline-block lg:-mt-10 text-6xl lg:text-[8rem] -rotate-3">Maurya</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          <h2 className="text-3xl lg:text-4xl font-bold text-[#111111]/80 leading-tight">
            Web Developer &<br />Tech Enthusiast
          </h2>
          <p className="max-w-md text-[#111111]/60 leading-relaxed font-medium">
            Motivated and creative aspiring Web Developer with hands-on experience in website development, poster design, and digital advertising. Passionate about building responsive web applications and exploring emerging technologies.
          </p>

          <div className="flex flex-wrap gap-4 pt-4">
            <button className="px-8 py-4 bg-[#FF4B22] text-white rounded-full font-bold text-sm flex items-center gap-2 hover:bg-[#E03A12] transition-colors group">
              Download Resume <Download size={18} className="group-hover:translate-y-1 transition-transform" />
            </button>
            <button className="px-8 py-4 bg-white border border-[#111111] text-[#111111] rounded-full font-bold text-sm flex items-center gap-2 hover:bg-[#F3F3F3] transition-colors group">
              Get In Touch <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </motion.div>
      </div>

      {/* Right Column */}
      <div className="flex-1 relative w-full max-w-xl">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="relative aspect-square rounded-[3rem] overflow-hidden group"
        >
          {/* Portrait Background Shape */}
          <div className="absolute inset-0 bg-[#FF4B22]/10 z-0"></div>
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[140%] aspect-square bg-[#FF4B22] rounded-full -mb-[40%] blur-[80px] opacity-20"></div>
          
          <Image 
            src={profilePic} 
            alt="Amar Jeet Maurya"
            fill
            className="object-cover transition-all duration-700"
            referrerPolicy="no-referrer"
          />

          {/* Hand-drawn decoration (simulated with SVG overlays) */}
          <svg className="absolute inset-0 pointer-events-none z-10" viewBox="0 0 100 100">
            <path d="M10,20 Q15,10 25,15" stroke="#FF4B22" strokeWidth="0.5" fill="none" className="animate-pulse" />
            <path d="M85,80 Q90,90 80,85" stroke="#FF4B22" strokeWidth="0.5" fill="none" />
            <circle cx="20" cy="80" r="1.5" fill="#FF4B22" />
          </svg>

          {/* Annotation */}
          <div className="absolute top-12 right-6 rotate-12 bg-white/90 backdrop-blur px-4 py-2 rounded-xl shadow-lg z-20">
            <p className="text-[10px] font-bold text-[#FF4B22] italic leading-tight">
              &quot;Turning Ideas into<br />Web Experiences&quot;
            </p>
          </div>
        </motion.div>

        {/* Floating Contact Card */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="absolute -bottom-10 -right-4 lg:-right-10 bg-white p-6 rounded-[2rem] shadow-2xl border border-[#111111]/5 space-y-4 min-w-[280px] z-30"
        >
          <div className="flex items-start gap-4">
            <div className="w-8 h-8 rounded-full bg-[#FF4B22]/10 flex items-center justify-center shrink-0">
              <MapPin size={14} className="text-[#FF4B22]" />
            </div>
            <div className="space-y-1">
              <p className="text-[10px] uppercase tracking-widest text-[#111111]/40 font-bold">Address</p>
              <p className="text-[12px] font-bold text-[#111111]">613/P No. 03, Shyam Bihar Colony, Faizullaganj, Lucknow</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-8 h-8 rounded-full bg-[#FF4B22]/10 flex items-center justify-center shrink-0">
              <Mail size={14} className="text-[#FF4B22]" />
            </div>
            <div className="space-y-1">
              <p className="text-[10px] uppercase tracking-widest text-[#111111]/40 font-bold">Email</p>
              <p className="text-[12px] font-bold text-[#111111]">maurya.amar@gmail.com</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-8 h-8 rounded-full bg-[#FF4B22]/10 flex items-center justify-center shrink-0">
              <Phone size={14} className="text-[#FF4B22]" />
            </div>
            <div className="space-y-1">
              <p className="text-[10px] uppercase tracking-widest text-[#111111]/40 font-bold">Phone</p>
              <p className="text-[12px] font-bold text-[#111111]">+91 79058 92369</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
