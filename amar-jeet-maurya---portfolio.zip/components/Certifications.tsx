'use client'

import React from 'react'
import { motion } from 'motion/react'
import { Award, Globe, Link as LinkIcon, Github, Linkedin } from 'lucide-react'

export default function Certifications() {
  return (
    <section className="py-24 px-6 max-w-7xl mx-auto">
      <div className="grid md:grid-cols-3 gap-8">
        {/* Certifications Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-[#F3F3F3] p-10 rounded-[2.5rem] space-y-8"
        >
          <div className="w-12 h-12 rounded-2xl bg-[#FF4B22] flex items-center justify-center shadow-[0_0_20px_rgba(255,75,34,0.2)]">
            <Award size={24} className="text-white" />
          </div>
          <div className="space-y-4">
            <h4 className="text-2xl font-black text-[#111111]">Certifications</h4>
            <div className="space-y-3">
              {["MS Office Professional", "Git & GitHub", "Website Development"].map((cert) => (
                <div key={cert} className="flex items-center gap-3 text-[#111111]/70 text-sm font-bold">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#FF4B22]"></div>
                  {cert}
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Languages Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="bg-white border border-[#111111]/5 p-10 rounded-[2.5rem] space-y-8 shadow-sm"
        >
          <div className="w-12 h-12 rounded-2xl bg-[#111111] flex items-center justify-center">
            <Globe size={24} className="text-[#FF4B22]" />
          </div>
          <div className="space-y-4">
            <h4 className="text-2xl font-black text-[#111111]">Languages</h4>
            <div className="flex flex-wrap gap-4">
              {["Hindi", "English"].map((lang) => (
                <div key={lang} className="px-5 py-2 rounded-full bg-[#F3F3F3] text-[#111111] text-xs font-black uppercase tracking-widest border border-[#111111]/5">
                  {lang}
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Quick Links Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="bg-[#111111] p-10 rounded-[2.5rem] space-y-8 text-white"
        >
          <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center">
            <LinkIcon size={24} className="text-[#FF4B22]" />
          </div>
          <div className="space-y-6">
            <div className="space-y-1">
              <h4 className="text-xl font-black">WEB & AI TECHNOLOGIST</h4>
              <p className="text-[#FF4B22] text-[10px] font-bold uppercase tracking-widest">amar-jeet.portfolio.netlify.com</p>
            </div>
            
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#FF4B22] transition-colors group">
                <Linkedin size={18} className="text-white" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#FF4B22] transition-colors group">
                <Github size={18} className="text-white" />
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
