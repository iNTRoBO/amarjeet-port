'use client'

import React from 'react'
import { motion } from 'motion/react'
import FolderFloat from './FolderFloat'

const techSkills = ["HTML5", "CSS3", "JavaScript", "React", "Next.js", "Tailwind CSS"]
const creativeSkills = ["AI Prompt Engineering", "Canva", "Poster Design", "Digital Ads", "Creativity"]
const softSkills = ["Problem Solving", "Communication", "Leadership", "Teamwork", "Adaptability"]

export default function Skills() {
  return (
    <section className="py-24 px-6 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-white border border-[#111111]/5 p-16 rounded-[3.5rem] shadow-[0_0_50px_rgba(0,0,0,0.02)]"
      >
        <div className="max-w-4xl mx-auto text-center space-y-16">
          <div className="space-y-4">
            <div className="inline-block px-6 py-2 rounded-full border border-[#111111]/10 text-xs font-black uppercase tracking-[0.2em] text-[#FF4B22] bg-[#111111]/5">
              Skills
            </div>
            <h3 className="text-6xl font-black text-[#111111]">
              My <span className="text-[#FF4B22] font-calligraphy normal-case text-8xl inline-block -rotate-3 ml-2">Skill Set</span>
            </h3>
          </div>

          <div className="flex flex-wrap justify-center gap-12 lg:gap-20 pt-10">
            <div className="flex flex-col items-center gap-4">
              <FolderFloat 
                items={techSkills}
                label="Technical"
                sublabel={`${techSkills.length} skills`}
                folderColor="#111111"
                frontColor="#1a1a1a"
                itemColor="#FF4B22"
                itemTextColor="#ffffff"
                labelColor="#ffffff"
                trigger="hover"
                width={220}
                height={160}
              />
            </div>

            <div className="flex flex-col items-center gap-4">
              <FolderFloat 
                items={creativeSkills}
                label="Creative"
                sublabel={`${creativeSkills.length} skills`}
                folderColor="#FF4B22"
                frontColor="#ff5d38"
                itemColor="#111111"
                itemTextColor="#ffffff"
                labelColor="#ffffff"
                trigger="hover"
                width={220}
                height={160}
              />
            </div>

            <div className="flex flex-col items-center gap-4">
              <FolderFloat 
                items={softSkills}
                label="Core"
                sublabel={`${softSkills.length} skills`}
                folderColor="#111111"
                frontColor="#1a1a1a"
                itemColor="#FF4B22"
                itemTextColor="#ffffff"
                labelColor="#ffffff"
                trigger="hover"
                width={220}
                height={160}
              />
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  )
}
