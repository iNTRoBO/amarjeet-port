'use client'

import React from 'react'
import { motion } from 'motion/react'
import { User } from 'lucide-react'
import Image from 'next/image'
import logo from '../src/assets/images/regenerated_image_1791186145599.png'

export default function Navbar() {
  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Education', href: '#education' },
  ]

  const rightItems = [
    { name: 'Projects', href: '#projects' },
    { name: 'Experience', href: '#experience' },
    { name: 'Contact', href: '#contact' },
  ]

  return (
    <motion.nav 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-6 left-1/2 -translate-x-1/2 z-50 px-6 py-2 bg-[#111111]/80 backdrop-blur-md rounded-full flex items-center gap-8 shadow-2xl border border-white/5"
    >
      <div className="flex items-center gap-6">
        {navItems.map((item) => (
          <a
            key={item.name}
            href={item.href}
            className="text-[10px] uppercase tracking-widest text-white/60 hover:text-[#FF4B22] transition-colors"
          >
            {item.name}
          </a>
        ))}
      </div>

      <div className="flex items-center gap-3 px-6 border-x border-white/10">
        <div className="relative w-16 h-16 overflow-hidden">
          <Image
            src={logo}
            alt="Logo"
            fill
            className="object-contain"
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        {rightItems.map((item) => (
          <a
            key={item.name}
            href={item.href}
            className="text-[10px] uppercase tracking-widest text-white/60 hover:text-[#FF4B22] transition-colors"
          >
            {item.name}
          </a>
        ))}
      </div>
    </motion.nav>
  )
}
