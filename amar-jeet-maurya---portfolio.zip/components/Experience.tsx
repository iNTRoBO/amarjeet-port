'use client'

import React from 'react'
import { motion } from 'motion/react'
import { Briefcase } from 'lucide-react'

export default function Experience() {
  const experiences = [
    {
      company: "Balaji Tech Solutions",
      role: "ERP and CRM Management",
      duration: "7 months",
      year: "2026",
      responsibilities: [
        "Assisted in the implementation and day-to-day management of ERP and CRM systems.",
        "Maintained and updated customer, sales, and operational data with accuracy.",
        "Coordinated with different departments to streamline business workflows and improve process efficiency.",
        "Generated reports and monitored data to support business decision-making.",
        "Provided technical support for CRM users and assisted in troubleshooting system-related issues.",
        "Contributed to website updates and digital business operations as part of the organization's technology team."
      ]
    },
    {
      company: "Graphic Design Intern",
      role: "College Poster & Advertisement Design Internship",
      duration: "3 Weeks",
      year: "2025",
      responsibilities: [
        "Designed promotional posters and digital advertisements.",
        "Created visually engaging marketing materials using Canva.",
        "Assisted in branding and social media promotional content."
      ]
    }
  ]

  return (
    <section id="experience" className="py-24 px-6 max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-[#111111] p-16 rounded-[4rem] text-white overflow-hidden relative"
      >
        <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
          <Briefcase size={400} strokeWidth={1} />
        </div>

        <div className="relative z-10 space-y-20">
          <div className="space-y-4">
            <div className="inline-block px-6 py-2 rounded-full border border-white/10 text-xs font-black uppercase tracking-[0.2em] text-[#FF4B22] bg-white/5">
              Professional Experience
            </div>
            <h3 className="text-6xl font-black text-white leading-tight">
              My Work <span className="text-[#FF4B22] font-calligraphy normal-case text-8xl inline-block -rotate-3 ml-2">Experience</span>
            </h3>
          </div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-[31px] top-4 bottom-4 w-px border-l-2 border-dotted border-[#FF4B22]/30"></div>

            <div className="space-y-24">
              {experiences.map((exp, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="relative pl-24 group"
                >
                  {/* Timeline Dot */}
                  <div className="absolute left-0 top-2 w-16 h-16 rounded-full border-4 border-[#111111] bg-[#FF4B22] flex items-center justify-center z-10 shadow-[0_0_20px_rgba(255,75,34,0.4)] group-hover:scale-110 transition-transform">
                    <span className="text-[10px] font-black uppercase">{exp.year}</span>
                  </div>

                  <div className="grid lg:grid-cols-3 gap-12">
                    <div className="lg:col-span-1 space-y-2">
                      <h4 className="text-3xl font-black text-white">{exp.company}</h4>
                      <p className="text-[#FF4B22] font-bold tracking-widest uppercase text-xs">{exp.role}</p>
                      <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">{exp.duration}</p>
                    </div>

                    <div className="lg:col-span-2">
                      <ul className="space-y-4">
                        {exp.responsibilities.map((resp, i) => (
                          <li key={i} className="flex gap-4 text-white/70 leading-relaxed font-medium group/item">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#FF4B22] mt-2 shrink-0 group-hover/item:scale-150 transition-transform"></span>
                            {resp}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  )
}
